"""
models.py (storage module)

StoredFileRecord is the structured result returned by every storage
operation -- exactly the fields the project spec asked for.
"""

from dataclasses import dataclass
from datetime import datetime, timezone


@dataclass
class StoredFileRecord:
    """Describes where an original file lives once it has been stored."""
    file_id: str
    user_id: str
    original_filename: str
    stored_filename: str
    storage_path: str    # string, not Path -- easy to serialize to JSON/API responses
    file_size: int
    created_at: str       # ISO 8601 string, consistent with the ingestion module

    @staticmethod
    def now_timestamp() -> str:
        return datetime.now(timezone.utc).isoformat()
