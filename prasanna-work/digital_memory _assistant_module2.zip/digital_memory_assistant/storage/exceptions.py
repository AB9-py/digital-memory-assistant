"""
exceptions.py (storage module)

Same philosophy as the ingestion module's exceptions: specific error
types so calling code can react to *why* something failed, not just
that it failed.
"""


class StorageError(Exception):
    """Base class for all errors raised by the storage module."""


class SourceFileNotFoundError(StorageError):
    """Raised when the local file we've been asked to store doesn't exist."""


class StorageWriteError(StorageError):
    """
    Raised when the file cannot be written to the storage location --
    e.g. the storage directory can't be created, or a disk/permission
    error occurs during the copy.
    """


class StorageDeleteError(StorageError):
    """Raised when a stored file exists but cannot be deleted (e.g. permissions)."""


class FileRecordNotFoundError(StorageError):
    """Raised when looking up or deleting a file_id that has no stored record."""


class InvalidIdentifierError(StorageError):
    """
    Raised when a user_id or file_id contains characters that are unsafe
    to use as part of a filesystem path (defense against path traversal,
    e.g. a user_id of "../../etc").
    """
