"""
storage_service.py

StorageService is the ONLY thing the rest of the application should
import and call. It doesn't know or care whether files end up on local
disk, S3, or anywhere else -- it just delegates to whatever
StorageBackend it was given.

This is the seam mentioned in the module docstring of file_repository.py:

    StorageService(backend=LocalFileSystemStorage())   # today
    StorageService(backend=S3StorageBackend(bucket=...))  # future, same interface

No other code in the project needs to change when that swap happens.
"""

import logging
from pathlib import Path

from storage.file_repository import StorageBackend, LocalFileSystemStorage
from storage.models import StoredFileRecord

logger = logging.getLogger(__name__)


class StorageService:
    """Public entry point for storing, retrieving, and deleting original files."""

    def __init__(self, backend: StorageBackend | None = None) -> None:
        # Defaults to local filesystem storage if no backend is supplied,
        # but any StorageBackend implementation can be injected here.
        self.backend = backend or LocalFileSystemStorage()

    def store_file(
        self,
        source_path: str,
        user_id: str,
        file_id: str,
        original_filename: str,
    ) -> StoredFileRecord:
        """
        Stores a validated local file. Returns a StoredFileRecord with
        everything needed to reference it later (storage_path, file_id, etc).
        """
        logger.info("Storing file '%s' (file_id=%s) for user_id=%s", original_filename, file_id, user_id)
        return self.backend.save(Path(source_path), user_id, file_id, original_filename)

    def get_file_info(self, user_id: str, file_id: str) -> StoredFileRecord:
        """Retrieves the stored record for a previously stored file."""
        return self.backend.get_record(user_id, file_id)

    def delete_file(self, user_id: str, file_id: str) -> None:
        """Deletes a previously stored file and its metadata."""
        self.backend.delete(user_id, file_id)
