"""
file_repository.py

Defines WHERE and HOW files are actually persisted.

This file contains two things:

1. `StorageBackend` -- an abstract base class (ABC) declaring the
   *contract* every storage backend must fulfill: save, get_record,
   delete. It contains no filesystem code at all.

2. `LocalFileSystemStorage` -- the concrete implementation used today,
   which fulfills that contract using the local disk.

Why bother with the abstract class if we only have one implementation?
Because `storage_service.py` (the rest of the app) is written against
`StorageBackend`, not against `LocalFileSystemStorage` directly. When
someone eventually writes `S3StorageBackend(StorageBackend)`, they only
need to implement the same three methods -- nothing in storage_service.py
or any calling code changes. This is the "swap the backend without
rewriting the app" requirement, made concrete.
"""

import json
import logging
import re
import shutil
from abc import ABC, abstractmethod
from pathlib import Path

from storage.exceptions import (
    SourceFileNotFoundError,
    StorageWriteError,
    StorageDeleteError,
    FileRecordNotFoundError,
    InvalidIdentifierError,
)
from storage.models import StoredFileRecord

logger = logging.getLogger(__name__)

# Where files live on disk for the local backend.
DEFAULT_BASE_STORAGE_DIR = Path("data/uploads")

# user_id and file_id become directory/file names, so we only allow
# a safe, restricted character set. This is the defense against path
# traversal mentioned in the concept notes above.
_SAFE_IDENTIFIER_PATTERN = re.compile(r"^[A-Za-z0-9_-]+$")

# Metadata sidecar filename, stored next to the actual file.
METADATA_FILENAME = "metadata.json"


def _validate_identifier(value: str, field_name: str) -> None:
    """Raises InvalidIdentifierError if value is unsafe to use in a path."""
    if not value or not _SAFE_IDENTIFIER_PATTERN.match(value):
        raise InvalidIdentifierError(
            f"Invalid {field_name}: {value!r}. Only letters, digits, "
            f"hyphens, and underscores are allowed."
        )


class StorageBackend(ABC):
    """Abstract contract that every storage backend must implement."""

    @abstractmethod
    def save(
        self,
        source_path: Path,
        user_id: str,
        file_id: str,
        original_filename: str,
    ) -> StoredFileRecord:
        """Persist the file at source_path and return its stored record."""

    @abstractmethod
    def get_record(self, user_id: str, file_id: str) -> StoredFileRecord:
        """Return the StoredFileRecord for a previously stored file."""

    @abstractmethod
    def delete(self, user_id: str, file_id: str) -> None:
        """Remove a previously stored file and its metadata."""


class LocalFileSystemStorage(StorageBackend):
    """
    Stores files on the local disk using the layout:

        <base_dir>/<user_id>/<file_id>/<file_id><extension>
        <base_dir>/<user_id>/<file_id>/metadata.json

    Using file_id (not the original filename) as the stored filename
    means uniqueness doesn't depend on directory nesting alone -- the
    filename itself is already collision-safe, which matters if this
    layout is ever flattened or mirrored into a bucket with flat keys.
    """

    def __init__(self, base_dir: Path | str = DEFAULT_BASE_STORAGE_DIR) -> None:
        self.base_dir = Path(base_dir)

    def _file_dir(self, user_id: str, file_id: str) -> Path:
        return self.base_dir / user_id / file_id

    def save(
        self,
        source_path: Path,
        user_id: str,
        file_id: str,
        original_filename: str,
    ) -> StoredFileRecord:
        source_path = Path(source_path)

        if not source_path.exists() or not source_path.is_file():
            raise SourceFileNotFoundError(f"Source file not found: {source_path}")

        _validate_identifier(user_id, "user_id")
        _validate_identifier(file_id, "file_id")

        file_dir = self._file_dir(user_id, file_id)
        extension = Path(original_filename).suffix.lower()
        stored_filename = f"{file_id}{extension}"
        destination_path = file_dir / stored_filename

        try:
            file_dir.mkdir(parents=True, exist_ok=True)

            # copy2 preserves file metadata (like modification time) and,
            # importantly, LEAVES THE ORIGINAL SOURCE FILE INTACT. We copy
            # rather than move so that if something fails downstream, the
            # caller's original upload isn't already gone.
            shutil.copy2(source_path, destination_path)

            file_size = destination_path.stat().st_size
            created_at = StoredFileRecord.now_timestamp()

            record = StoredFileRecord(
                file_id=file_id,
                user_id=user_id,
                original_filename=original_filename,
                stored_filename=stored_filename,
                storage_path=str(destination_path),
                file_size=file_size,
                created_at=created_at,
            )

            # Save a small sidecar JSON file so get_record() can look up
            # this file's info later without needing any external database.
            metadata_path = file_dir / METADATA_FILENAME
            metadata_path.write_text(
                json.dumps(record.__dict__, indent=2), encoding="utf-8"
            )

            logger.info(
                "Stored file_id=%s for user_id=%s at %s", file_id, user_id, destination_path
            )
            return record

        except OSError as exc:
            # Covers: can't create directory (e.g. base_dir path is
            # actually a file, or permissions denied), disk full,
            # copy failure, etc.
            logger.exception("Failed to store file_id=%s for user_id=%s", file_id, user_id)
            raise StorageWriteError(f"Could not store file: {exc}") from exc

    def get_record(self, user_id: str, file_id: str) -> StoredFileRecord:
        _validate_identifier(user_id, "user_id")
        _validate_identifier(file_id, "file_id")

        metadata_path = self._file_dir(user_id, file_id) / METADATA_FILENAME

        if not metadata_path.exists():
            raise FileRecordNotFoundError(
                f"No stored file found for user_id={user_id}, file_id={file_id}"
            )

        data = json.loads(metadata_path.read_text(encoding="utf-8"))
        return StoredFileRecord(**data)

    def delete(self, user_id: str, file_id: str) -> None:
        _validate_identifier(user_id, "user_id")
        _validate_identifier(file_id, "file_id")

        file_dir = self._file_dir(user_id, file_id)

        if not file_dir.exists():
            raise FileRecordNotFoundError(
                f"No stored file found for user_id={user_id}, file_id={file_id}"
            )

        try:
            shutil.rmtree(file_dir)
            logger.info("Deleted file_id=%s for user_id=%s", file_id, user_id)
        except OSError as exc:
            logger.exception("Failed to delete file_id=%s for user_id=%s", file_id, user_id)
            raise StorageDeleteError(f"Could not delete file: {exc}") from exc
