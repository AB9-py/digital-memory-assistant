"""
The `storage` package: original file storage for the
Digital Memory Assistant project.

Public entry point: StorageService (store_file / get_file_info / delete_file)
"""
