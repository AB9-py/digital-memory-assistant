"""
test_storage.py

Tests for StorageService / LocalFileSystemStorage.

Each test gets its own isolated `base_dir` under pytest's tmp_path
fixture, so tests never touch the real data/uploads/ folder and never
interfere with each other.
"""

import sys
import uuid
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from storage.exceptions import (
    SourceFileNotFoundError,
    FileRecordNotFoundError,
    StorageWriteError,
)
from storage.file_repository import LocalFileSystemStorage
from storage.storage_service import StorageService


@pytest.fixture
def storage_service(tmp_path) -> StorageService:
    """A StorageService backed by a fresh, isolated local directory."""
    backend = LocalFileSystemStorage(base_dir=tmp_path / "uploads")
    return StorageService(backend=backend)


@pytest.fixture
def sample_source_file(tmp_path) -> Path:
    """A fake 'already validated' source file, sitting outside storage."""
    path = tmp_path / "incoming" / "notes.pdf"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(b"%PDF-1.4\nfake pdf content for testing")
    return path


# ---------------------------------------------------------------------
# Successful storage
# ---------------------------------------------------------------------
def test_successful_storage(storage_service, sample_source_file):
    file_id = str(uuid.uuid4())
    record = storage_service.store_file(
        source_path=str(sample_source_file),
        user_id="user123",
        file_id=file_id,
        original_filename="notes.pdf",
    )

    assert record.file_id == file_id
    assert record.user_id == "user123"
    assert record.original_filename == "notes.pdf"
    assert record.stored_filename == f"{file_id}.pdf"
    assert record.file_size > 0
    assert Path(record.storage_path).exists()
    assert Path(record.storage_path).name == record.stored_filename


def test_stored_file_content_matches_source(storage_service, sample_source_file):
    file_id = str(uuid.uuid4())
    record = storage_service.store_file(
        str(sample_source_file), "user123", file_id, "notes.pdf"
    )

    original_bytes = sample_source_file.read_bytes()
    stored_bytes = Path(record.storage_path).read_bytes()
    assert original_bytes == stored_bytes

    # The original source file should still exist -- we copy, not move.
    assert sample_source_file.exists()


# ---------------------------------------------------------------------
# Duplicate original filenames
# ---------------------------------------------------------------------
def test_duplicate_original_filenames_do_not_collide(storage_service, tmp_path):
    """Two different files, same original name, must both be stored safely."""
    source_a = tmp_path / "a" / "notes.pdf"
    source_b = tmp_path / "b" / "notes.pdf"
    source_a.parent.mkdir(parents=True)
    source_b.parent.mkdir(parents=True)
    source_a.write_bytes(b"%PDF-1.4\ncontent A")
    source_b.write_bytes(b"%PDF-1.4\ncontent B")

    file_id_a = str(uuid.uuid4())
    file_id_b = str(uuid.uuid4())

    record_a = storage_service.store_file(str(source_a), "user123", file_id_a, "notes.pdf")
    record_b = storage_service.store_file(str(source_b), "user123", file_id_b, "notes.pdf")

    # Both succeeded, both report the same original_filename...
    assert record_a.original_filename == record_b.original_filename == "notes.pdf"
    # ...but stored at completely different, non-colliding paths.
    assert record_a.storage_path != record_b.storage_path
    assert Path(record_a.storage_path).read_bytes() == b"%PDF-1.4\ncontent A"
    assert Path(record_b.storage_path).read_bytes() == b"%PDF-1.4\ncontent B"


# ---------------------------------------------------------------------
# Retrieval
# ---------------------------------------------------------------------
def test_retrieval_returns_matching_record(storage_service, sample_source_file):
    file_id = str(uuid.uuid4())
    stored_record = storage_service.store_file(
        str(sample_source_file), "user123", file_id, "notes.pdf"
    )

    fetched_record = storage_service.get_file_info("user123", file_id)

    assert fetched_record == stored_record


def test_retrieval_of_unknown_file_id_raises(storage_service):
    with pytest.raises(FileRecordNotFoundError):
        storage_service.get_file_info("user123", str(uuid.uuid4()))


# ---------------------------------------------------------------------
# Deletion
# ---------------------------------------------------------------------
def test_deletion_removes_file_and_metadata(storage_service, sample_source_file):
    file_id = str(uuid.uuid4())
    record = storage_service.store_file(
        str(sample_source_file), "user123", file_id, "notes.pdf"
    )
    stored_dir = Path(record.storage_path).parent
    assert stored_dir.exists()

    storage_service.delete_file("user123", file_id)

    assert not stored_dir.exists()

    # And it should no longer be retrievable.
    with pytest.raises(FileRecordNotFoundError):
        storage_service.get_file_info("user123", file_id)


def test_deleting_unknown_file_id_raises(storage_service):
    with pytest.raises(FileRecordNotFoundError):
        storage_service.delete_file("user123", str(uuid.uuid4()))


# ---------------------------------------------------------------------
# Missing source file
# ---------------------------------------------------------------------
def test_missing_source_file_raises(storage_service, tmp_path):
    missing_source = tmp_path / "does_not_exist.pdf"

    with pytest.raises(SourceFileNotFoundError):
        storage_service.store_file(
            str(missing_source), "user123", str(uuid.uuid4()), "does_not_exist.pdf"
        )


# ---------------------------------------------------------------------
# Invalid storage directory
# ---------------------------------------------------------------------
def test_invalid_storage_directory_raises(tmp_path, sample_source_file):
    """
    Simulate an unusable storage location by making base_dir point to a
    path that is already occupied by a regular FILE, not a directory.
    Creating a subdirectory under a file is impossible on any OS.
    """
    blocked_path = tmp_path / "not_a_directory"
    blocked_path.write_text("I am a file, not a directory")

    backend = LocalFileSystemStorage(base_dir=blocked_path)
    service = StorageService(backend=backend)

    with pytest.raises(StorageWriteError):
        service.store_file(
            str(sample_source_file), "user123", str(uuid.uuid4()), "notes.pdf"
        )
